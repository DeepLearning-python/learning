import pymongo
from datetime import datetime

client = pymongo.MongoClient()
mydb = client["lidar"]
mycollection = mydb["trackingViolation"]

# x = my_collection.delete_many({})
# 2021-04-11 generate_figure 2021-04-13
start = datetime(2021, 4, 11, 00, 00, 00)
end = datetime(2021, 4, 13, 00, 00, 00)

# records = mycollection.find({'date':{'$gte':'2021-04-12 00:00:00', '$lt':'2021-05-27 00:00:00'}})
records = mycollection.find({'date': {'$lt': end, '$gte': start}, 'violated': {'$ne': 'Not'}})
# print(type(records))
print(records[0])

import pandas as pd
data = pd.DataFrame.from_dict(records[0]['coordinates'])
print(data)
# for doc in records:
#     print(doc)

# from datetime import datetime
# from pymongo import Connection

# # i have updated and included the complete code 
# client = Connection('localhost', 27017)
# db = client['database'] # your database name
# inoshare = db['inoshare']


# # convert your date string to datetime object
# start = datetime(2014, 9, 24, 7, 51, 04)
# end = datetime(2014, 9, 24, 7, 52, 04)

# inoshare.find( {'id_no': 1, 'datahora': {'$lt': end, '$gte': start}, 'porta': 'A0'})
# <pymongo.cursor.Cursor at 0x7f9aafd64a90>

# inoshare.find_one( {'id_no': 1, 'datahora': {'$lt': end, '$gte': start}, 'porta': 'A0'})

# {u'_id': ObjectId('5435be9ce7b9916e02ed2cb5'),
#  u'datahora': datetime.datetime(2014, 9, 24, 7, 51, 5),
#  u'id_no': 1.0,
#  u'lab': u'2',
#  u'porta': u'A0',
#  u'sensor': u'1',
#  u'valor': u'917'}


# value = mycollection.find_one(sort=[("date", -1)])["date"]
# print(value)
# print(type(value))

# value = mycollection.find_one(sort=[("date", 1)])["date"]
# print(value)


# # datalist = { 'date': '2021-05-27 10:03:34',
# #     'coordinates': [
# #       {'X':211,'Y':175},
# #       {'X':198,'Y':170},
# #       {'X':198,'Y':174},
# #       {'X':199,'Y':175}
# #     ],
# #     'violated': 'Yes' }

# dt = datetime.datetime.fromtimestamp(1618196253).strftime('%Y-%m-%dT%H:%M:%S.000Z')
# d = datetime.datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.000Z")

# datalist = { 'date': d,
#     'coordinates': [
#       {'X':211,'Y':175},
#       {'X':198,'Y':170},
#       {'X':198,'Y':174},
#       {'X':199,'Y':175}
#     ],
#     'violated': 'Yes' }

# x = mycollection.insert_one(datalist)
# print(x.inserted_id)


# #   { 'date': '2021-05-27 10:06:34',
# #     'coordinates': [
# #       {'X':211,'Y':175},
# #       {'X':198,'Y':170},
# #       {'X':198,'Y':174},
# #       {'X':199,'Y':175}
# #     ],
# #     'violated': 'No' },