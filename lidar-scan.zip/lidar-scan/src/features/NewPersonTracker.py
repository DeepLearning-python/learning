import math
import numpy as np
import pandas as pd
import pymongo
import datetime


class PersonTracker:
    """ PersonTracker

    This class stores Person detected, also its x,y
    coordinates in the space for every frame
    """

    def __init__(self):
        # Store the person object with unique ID in dictionary
        self.active_persons_X = pd.DataFrame()
        self.active_persons_Y = pd.DataFrame()
        self.indexFrame = []  # stores frameName which is the timestamp
        self.sensitive_startpoint = (135,125)
        self.sensitive_endpoint = (175,160)
        # self.over_startpoint = (145,85)
        self.over_startpoint = (145,45)
        # self.overn_endpoint = (190,120)
        self.overn_endpoint = (195,90)
        # self.sla_startpoint = (215,70)
        self.sla_startpoint = (215,95)
        self.sla_endpoint = (245,170)
        client = pymongo.MongoClient()
        mydb = client["lidar"]
        self.mycollection = mydb["trackingViolation"]
        self.debug = True

    # def saveActivePersons(self):
    #     """[summary]
    #     """
    #     s = pd.Series(self.indexFrame)
    #     self.active_persons_X = self.active_persons_X.set_index([s])
    #     self.active_persons_Y = self.active_persons_Y.set_index([s])
    #     self.active_persons_X.to_csv("active_persons_X.csv")
    #     self.active_persons_Y.to_csv("active_persons_Y.csv")

    def insertToDatabase(self, dataFrame, violationResult):
        # date = datetime.datetime.fromtimestamp(int(dataFrame.index[0])).strftime('%Y-%m-%d %H:%M:%S')
        # 1618195127
        # 1624858075.7310863
        print(dataFrame.index[0])
        date = datetime.datetime.fromtimestamp(int(str(dataFrame.index[0]).split(".")[0])).strftime('%Y-%m-%dT%H:%M:%S.000Z')
        print(date)
        date = datetime.datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.000Z")
        print(date)
        dataFrame.columns = ['X', 'Y']
        coordinates = dataFrame.to_dict('records')
        datalist = {'date': date,
                    'coordinates': coordinates,
                    'violated': violationResult}
        self.mycollection.insert_one(datalist)

    def ruleViolation(self, sensitiveArea, violationArea, x, y):
        violated = "Not"
        sensitive_startpoint = sensitiveArea[0]
        sensitive_endpoint = sensitiveArea[1]
        violation_startpoint = violationArea[0]
        violation_endpoint = violationArea[1]
        # print(sensitive_startpoint, sensitive_endpoint, violation_startpoint, violation_endpoint)
        record = {
            'X' : x.tolist(),
            'Y' : y.tolist()
        }
        # create a dataframe
        dataframe = pd.DataFrame(record, columns=['X', 'Y'])
        # print(dataframe)
        # selecting rows based on condition
        rslt_df = dataframe.loc[
            (dataframe['X'] > sensitive_startpoint[0]) & (dataframe['X'] < sensitive_endpoint[0]) &
            (dataframe['Y'] > sensitive_startpoint[1]) & (dataframe['Y'] < sensitive_endpoint[1])
                            ]
        if(len(rslt_df) > 0):
            # print(rslt_df)
            # firstIndex = rslt_df.index[0]
            firstIndex = rslt_df.index[len(rslt_df)-1]
            # print(firstIndex)
            dataframe = dataframe.iloc[0:firstIndex, :]
            rslt_df = dataframe.loc[
                (dataframe['X'] > violation_startpoint[0]) & (dataframe['X'] < violation_endpoint[0]) &
                (dataframe['Y'] > violation_startpoint[1]) & (dataframe['Y'] < violation_endpoint[1])]
            if(len(rslt_df) > 0):
                firstIndex = rslt_df.index[0]
                # print(firstIndex)
                dataframe = dataframe.iloc[0:firstIndex, :]
                violated = "Yes"
                # print("violated="+violated)
        return dataframe['X'].to_numpy(), dataframe['Y'].to_numpy(), violated

    def trimData(self):
        """[summary]
        """
        firstColumnValues = self.active_persons_X[self.active_persons_X.columns[0]].values
        nonZeroIndex = np.nonzero(firstColumnValues)[0][0]
        # remove the first nonZeroIndex rows
        self.active_persons_X = self.active_persons_X.iloc[nonZeroIndex:]
        self.active_persons_X = self.active_persons_X.reset_index(drop=True)
        self.active_persons_Y = self.active_persons_Y.iloc[nonZeroIndex:]
        self.active_persons_Y = self.active_persons_Y.reset_index(drop=True)
        self.indexFrame = self.indexFrame[nonZeroIndex:]

    def removeNoise(self):
        s = pd.Series(self.indexFrame)
        X_data = self.active_persons_X.copy()
        Y_data = self.active_persons_Y.copy()
        X_data = X_data.set_index([s])
        Y_data = Y_data.set_index([s])

        columnNames = X_data.columns

        for column in columnNames:
            colData = X_data[column].values
            dataLength = len(colData)
            if (dataLength > 20):
                temp1 = colData[dataLength-20:dataLength]
                if(len(temp1[temp1 > 0]) == 0):
                    colData = colData[colData > 0]
                    if len(colData) > 20:
                        # print(column)
                        XcolDataPD = X_data[column].to_frame()
                        YcolDataPD = Y_data[column].to_frame()
                        XcolDataPD = XcolDataPD.loc[XcolDataPD[column] > 0]
                        YcolDataPD = YcolDataPD.loc[YcolDataPD[column] > 0]
                        XcolDataPD['Y'] = YcolDataPD[column]
                        x = XcolDataPD[XcolDataPD.columns[0]].values
                        y = XcolDataPD[XcolDataPD.columns[1]].values
                        x_, y_, violated = self.ruleViolation([self.sensitive_startpoint, self.sensitive_endpoint],
                                                                [self.sla_startpoint, self.sla_endpoint], x, y)

                        if (violated == "Yes"):
                            self.insertToDatabase(XcolDataPD, "SLA violated")
                            print("SLA violated="+violated)
                        else:
                            x_, y_, violated = self.ruleViolation([self.sensitive_startpoint, self.sensitive_endpoint],
                                                                    [self.over_startpoint, self.overn_endpoint], x, y)
                            if (violated == "Yes"):
                                self.insertToDatabase(XcolDataPD, "Oven violated")
                                print("Oven violated="+violated)
                            else:
                                self.insertToDatabase(XcolDataPD, "Not")
                                print("Not violated="+violated)

                        if (self.debug):
                            XcolDataPD.to_csv("./data/interim/"+column+".csv")
                        # after extracting data discard the column
                        self.active_persons_X.drop(column, axis='columns', inplace=True)
                        self.active_persons_Y.drop(column, axis='columns', inplace=True)
                    else:
                        # discard the column
                        self.active_persons_X.drop(column, axis='columns', inplace=True)
                        self.active_persons_Y.drop(column, axis='columns', inplace=True)
                else:
                    # exist for loop to iterate the column as these columsn are active persons
                    break

    def updateIndex(self, frameName):
        self.indexFrame.append(frameName)
        # print("self.active_persons_X.columns length="+str(len(self.active_persons_X.columns)))
        if(len(self.active_persons_X.columns) > 25):
            self.removeNoise()
            self.trimData()

    def update(self, objects_rect, frameName):
        # Get center point of new person
        # local variable of Persons to be maintained
        # during update then ad back to global self.persons
        original_objects_rect = objects_rect.copy()
        personID = []  # to track person id
        for i in range(len(objects_rect)):
            personID.append('dummyid')

        if len(self.active_persons_X.columns) == 0:
            count = len(self.active_persons_X.columns)
            personID_Counter = 0
            for rect in objects_rect:
                x, y, w, h = rect
                cx = (x + x + w) // 2
                cy = (y + y + h) // 2
                # print(f"cx={cx}, cy={cy}")
                self.active_persons_X[frameName+'_'+str(count)] = [cx]
                self.active_persons_Y[frameName+'_'+str(count)] = [cy]
                personID[personID_Counter] = [x, y, frameName+'_'+str(count)]  # to track person id
                count += 1
                personID_Counter += 1
        else:
            lengthOfNewPersons = len(objects_rect)
            if lengthOfNewPersons > 0:
                activePersonColumns = self.active_persons_X.columns
                lengthOfActivePersons = len(activePersonColumns)
                colnp_X = np.zeros(lengthOfActivePersons)
                colnp_Y = np.zeros(lengthOfActivePersons)
                # loop till we assign new person to previous 20 frames
                # else consider new person appeared in the current frame, changed from 10 tp 20
                lastIndex = 1
                # print("self.active_persons_X.shape[0]="+str(self.active_persons_X.shape[0]))
                for j in range(0, self.active_persons_X.shape[0]):
                    lengthOfNewPersons = len(objects_rect)
                    distMatrix = np.zeros((lengthOfActivePersons, lengthOfNewPersons))
                    distMatrix = self.findDistance(distMatrix, objects_rect, lastIndex) # euclidean distance matrix between current localised persons to the previous frame localized persons
                    # print(distMatrix)
                    added_objects_rect = []
                    # loop through new persons to assign to active persons
                    assigned = 0 # keep track of how many new person assigned to active person
                    for i in range(0, lengthOfNewPersons):
                        minvalue =np.min(distMatrix)  #get minimum euclidean distance value
                        if minvalue <= 15:  # changed euclidean distance from 10 to 15
                            k = np.argwhere(distMatrix == minvalue)  #get location of minimum distance position in the matrix
                            """
                            distMatrix =  np.array([[20,2,3,4,5,16],
                                                    [30,6,6,7,2,60],
                                                    [35,8,5,1,21,91],
                                                    [16,4,2,7,8,36]])
                            minvalue =np.min(distMatrix) # minvalue = 1
                            k = np.argwhere(distMatrix == minvalue) # k = [ [2, 3] ]
                            """
                            # print(k[0][0], k[0][1])
                            colnp_X[k[0][0]] = objects_rect[k[0][1]][0]
                            colnp_Y[k[0][0]] = objects_rect[k[0][1]][1]
                            personID[k[0][1]] = [objects_rect[k[0][1]][0], objects_rect[k[0][1]][1], list(self.active_persons_X)[k[0][0]]]  # to track person id
                            distMatrix[:, k[0][1]] = 9999  # set column to high value as the new person is assigned to active person
                            distMatrix[k[0][0], :] = 9999  # set row to high value as the active person is assigned to new person
                            added_objects_rect.append(objects_rect[k[0][1]])
                            assigned += 1

                        else:
                            # no minimum distance so exit comparison and assign new person to previous frame persons
                            break
                    # remove the assigned rect object from irugubak rect object
                    for rect in added_objects_rect:
                        objects_rect.remove(rect)

                    if len(objects_rect) == 0:
                        break
                    elif j >= 10:  #exit the loop after looking for previous 10 frames
                        break
                    else:
                        lastIndex += 1

                # append the new person to the active person
                self.active_persons_X = self.active_persons_X.append(pd.DataFrame(colnp_X.reshape(1,-1), columns=list(self.active_persons_X)), ignore_index=True)
                self.active_persons_Y = self.active_persons_Y.append(pd.DataFrame(colnp_Y.reshape(1,-1), columns=list(self.active_persons_Y)), ignore_index=True)

                # add new person in the current frame to active persons
                if len(objects_rect) > 0:
                    numberOfRows = self.active_persons_X.shape[0]
                    for rect in objects_rect:
                        colnp_X = np.zeros(numberOfRows)
                        colnp_Y = np.zeros(numberOfRows)
                        colnp_X[numberOfRows-1] = rect[0]
                        colnp_Y[numberOfRows-1] = rect[1]
                        colLength = self.active_persons_X.shape[1]
                        self.active_persons_X[frameName+'_'+str(colLength)] =  colnp_X.tolist()
                        self.active_persons_Y[frameName+'_'+str(colLength)] =  colnp_Y.tolist()
                        personID_Counter = 0
                        for rect1 in original_objects_rect:
                            if rect1 == rect:
                                x, y, w, h = rect
                                personID[personID_Counter] = [ x, y, frameName+'_'+str(colLength) ]  # to track person id
                                break
                            personID_Counter += 1

                # what is left over in distMatrix are new person distance
                # is more than the threshold eg. 10 meanning they are new person
                """after assignment matrix will be like below
                distMatrix =  np.array([[9999,9999,9999,9999,9999,9999],
                                        [9999,9999,9999,9999,9999,9999],
                                        [9999,9999,9999,9999,9999,9999],
                                        [9999,9999,9999,9999,9999,9999]])
                """

        return personID

    def findDistance(self, distMatrix, objects_rect, lastIndex):
        """[summary]

        Args:
            distMatrix ([type]): [description]
            objects_rect ([type]): [description]
            lastIndex ([int]): [which last index of the row to be compared]

        Returns:
            distMatrix [type]: euclidean distance matrix between active_persons_X[shape - lastIndex] and objects_rect
        """
        # ix = self.active_persons_X.index[-1]
        ix = self.active_persons_X.shape[0]-lastIndex
        # persons_X = self.active_persons_X.tail(1)
        persons_X = self.active_persons_X.iloc[[ix]]
        # persons_Y = self.active_persons_Y.tail(1)
        persons_Y = self.active_persons_Y.iloc[[ix]]
        columns = persons_X.columns
        count = 0
        for rect in objects_rect:
            x, y, w, h = rect
            cx = (x + x + w) // 2
            cy = (y + y + h) // 2
            for i in range(0, len(columns)):
                x1 = persons_X.at[ix, columns[i]]
                y1 = persons_Y.at[ix, columns[i]]
                dist = math.hypot(cx - x1, cy - y1)
                distMatrix[i, count] = dist
            count += 1

        return distMatrix
