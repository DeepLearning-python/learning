import cv2

from .NewPersonTracker import PersonTracker


class TrackMovement:
    """[summary]
    """

    def __init__(self):
        # Object detection
        self.object_detector = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=70, detectShadows = False)
        self.tracker = PersonTracker()
        self.sensitive_startpoint = (135,125)
        self.sensitive_endpoint = (175,160)
        # self.over_startpoint = (145,85)
        self.over_startpoint = (145,45)
        # self.overn_endpoint = (190,120)
        self.overn_endpoint = (195,90)
        # self.sla_startpoint = (215,70)
        self.sla_startpoint = (215,95)
        self.sla_endpoint = (245,170)

    def detectAndTrack(self, roiOriginal, taskTime):
        """
        - perform background subtraction, 
        - find contour(possibly human) having area greater than threshold to eliminate noise
        - person track
        """

        # Extract Region of interest
        roi = roiOriginal

        # 1. Person Detection
        mask = self.object_detector.apply(roi)
        _, mask = cv2.threshold(mask, 250, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        detections = []

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 5:
                cv2.drawContours(roi, [cnt], -1, (255, 0, 0), 5)
                x, y, w, h = cv2.boundingRect(cnt)
                # cv2.rectangle(roi, (x,y), (x+w, y+h), (0, 0, 255), 1)
                detections.append([x, y, w, h])

        roi = cv2.rectangle(roi, self.sensitive_startpoint, self.sensitive_endpoint, (255, 0, 0), 1)
        roi = cv2.rectangle(roi, self.over_startpoint, self.overn_endpoint, (0, 0, 255), 1)
        roi = cv2.rectangle(roi, self.sla_startpoint, self.sla_endpoint, (0, 0, 255), 1)
        # print("len(detections)="+str(len(detections)))

        # 2. Person Tracking
        if len(detections) > 0:
            self.tracker.update(detections, str(taskTime))
            self.tracker.updateIndex(str(taskTime))

        # cv2.imwrite("roi.jpg", roi)
        # return cv2.vconcat([roiOriginal, roi])
        return roi


# tracker.saveActivePersons()
# # tracker.savePersons()
# #cap.release()
# cv2.destroyAllWindows()
