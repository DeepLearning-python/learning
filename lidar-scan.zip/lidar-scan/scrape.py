import datetime
# date = datetime.datetime.fromtimestamp(int('1624858075.7310863')).strftime('%Y-%m-%dT%H:%M:%S.000Z')
date = datetime.datetime.fromtimestamp(int('1624858075')).strftime('%Y-%m-%dT%H:%M:%S.000Z')
print(date)
date = datetime.datetime.strptime(date, "%Y-%m-%dT%H:%M:%S.000Z")
print(date)


# dt = datetime.datetime.fromtimestamp(1618196253).strftime('%Y-%m-%dT%H:%M:%S.000Z')
# dt
# d = datetime.datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S.000Z")
# d

# datetime.datetime.fromtimestamp(1618196253).strftime('%Y-%m-%d %H:%M:%S')
# datetime.datetime.fromtimestamp(1618196253).strftime('%Y-%m-%d %H:%M:%S')


# datetime.datetime.fromtimestamp(1618195127).strftime('%Y-%m-%dT%H:%M:%S.000Z')


# datetime.datetime.now()
# datetime.datetime.now()

# 1624858075.7310863