#!/usr/bin/env python3
'''Animates distances and measurment quality'''
from rplidar import RPLidar
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.animation as animation
import time
import io
import cv2
# from PIL import Image
import queue
import threading
from src.features.TrackMovement import TrackMovement

import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output
import plotly.express as px

taskqueue = queue.Queue()
roiTracked = cv2.imread('roi.jpg')


class ProducerThread(threading.Thread):

    def __init__(self, name=None):
        super(ProducerThread, self).__init__()
        self.name = name
        self.PORT_NAME = '/dev/ttyUSB0'
        self.DMAX = 10000  # milli meter
        self.IMIN = 0
        self.IMAX = 255
        self.encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]

    def get_img_from_fig(self, fig, dpi=50):
        buf = io.BytesIO()
        fig.savefig(buf, format="jpeg", dpi=dpi)
        buf.seek(0)
        img_arr = np.frombuffer(buf.getvalue(), dtype=np.uint8)
        buf.close()
        img = cv2.imdecode(img_arr, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        return img

    def update_line(self, num, iterator, line, fig):
        global taskqueue
        scan = next(iterator)
        offsets = np.array([
            (np.radians((360-meas[1])), meas[2]) for meas in scan])
        line.set_offsets(offsets)
        intens = np.array([meas[0] for meas in scan])
        line.set_array(intens)
        img = np.array(fig.canvas.buffer_rgba())
        img = np.rint(img[..., :3] @ [0.2126, 0.7152, 0.0722]).astype(np.uint8)
        # im = Image.fromarray(img)
        # im = np.asarray(im)
        im = img[50: 430, 130: 520]
        # im.save('./images/'+str(time.time())+'.jpeg')
        taskqueue.put([im, (time.time())])
        return line,

    def run(self):
        lidar = RPLidar(self.PORT_NAME)
        fig = plt.figure()
        ax = plt.subplot(111, projection='polar')
        line = ax.scatter([0, 0], [0, 0], s=1, c=[self.IMIN, self.IMAX], cmap=plt.cm.Oranges_r, lw=0)
        ax.set_rmax(self.DMAX)
        ax.set_rticks([int(self.DMAX*3/4), self.DMAX])
        ax.grid(True)
        iterator = lidar.iter_scans(max_buf_meas=800)
        ani = animation.FuncAnimation(fig, self.update_line, fargs=(iterator, line, fig), interval=1)
        plt.show()
        lidar.stop()
        lidar.disconnect()


class ConsumerThread(threading.Thread):
    def __init__(self, name=None):
        super(ConsumerThread, self).__init__()
        self.name = name
        self.trackMovement = TrackMovement()

    def run(self):
        global taskqueue
        global roiTracked
        print("consumer")
        flag = True

        while flag:
            if not taskqueue.empty():
                # print(taskqueue.qsize())
                roiOriginal, taskTime = taskqueue.get()
                roi = self.trackMovement.detectAndTrack(roiOriginal, taskTime)
                roiTracked = roi
                # print("roiTracked type="+str(type(roiTracked)))
                # print(taskqueue.qsize())
            else:
                time.sleep(1)
                # print("taskqueue is empty")
        print("end of consumer")
        taskqueue.task_done()



app = dash.Dash(__name__)

app.layout = html.Div(
    children=[
        html.H3("Edit text input to see loading state"),
        dcc.Graph(id='graph', figure={}),
        dcc.Interval(id="interval", interval=350),
    ],
)


@app.callback(Output("graph", "figure"), Input("interval", "n_intervals"))
def image_trigger(n_intervals):
    # img = cv2.imread('roi.jpg')
    # print("img type="+str(type(img)))
    # print("roiTracked type="+str(type(roiTracked)))
    rgb = cv2.cvtColor(roiTracked, cv2.COLOR_RGBA2RGB)
    fig = px.imshow(rgb)
    return fig

if __name__ == "__main__":
    p = ProducerThread(name='producer')
    p.start()
    c = ConsumerThread(name='consumer')
    c.start()
    app.run_server()
    # app.run_server(debug=True, port=8010, host='localhost')
    # print("task queue waiting")
    # taskqueue.join()