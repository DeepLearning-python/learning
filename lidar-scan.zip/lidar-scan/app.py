'''Animates distances and measurment quality'''
from rplidar import RPLidar
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.animation as animation
import time
import io
import cv2
# from PIL import Image
import queue
import threading
from src.features.TrackMovement import TrackMovement

import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import plotly.express as px
import os
import pathlib
# import plotly.graph_objs as go
# import dash_daq as daq
import pandas as pd
import datetime
import pymongo
from matplotlib.backends.backend_agg import FigureCanvasAgg
import sys

taskqueue = queue.Queue()
roiTracked = cv2.imread('./data/images/roi.jpg')
noActivity = roiTracked.copy()


class ProducerThread(threading.Thread):

    # def __init__(self, name=None):
    #     super(ProducerThread, self).__init__()

    # def run(self):
    #     import os
    #     dirFiles = os.listdir("../images/")  # list of directory files
    #     dirFiles.sort()  # good initial sort but doesnt sort numerically very well
    #     sorted(dirFiles)  # sort numerically in ascending order
    #     for filename in dirFiles:
    #         # print(filename)
    #         img = cv2.imread(os.path.join("../images/", filename))
    #         # Extract Region of interest
    #         roi = img[50: 430, 130: 520]
    #         taskqueue.put([roi, str(filename.split(".")[0])])
    #         time.sleep(0.25)


    def __init__(self, name=None):
        super(ProducerThread, self).__init__()
        self.name = name
        self.PORT_NAME = '/dev/ttyUSB0'
        self.DMAX = 10000  # milli meter
        self.IMIN = 0
        self.IMAX = 255
        self.encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]

    def get_img_from_fig(self, fig, dpi=50):
        buf = io.BytesIO()
        fig.savefig(buf, format="jpeg", dpi=dpi)
        buf.seek(0)
        img_arr = np.frombuffer(buf.getvalue(), dtype=np.uint8)
        buf.close()
        img = cv2.imdecode(img_arr, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        return img

    def update_line(self, num, iterator, line, fig):
        global taskqueue
        scan = next(iterator)
        offsets = np.array([
            (np.radians((360-meas[1])), meas[2]) for meas in scan])
        line.set_offsets(offsets)
        intens = np.array([meas[0] for meas in scan])
        line.set_array(intens)
        img = np.array(fig.canvas.buffer_rgba())
        img = np.rint(img[..., :3] @ [0.2126, 0.7152, 0.0722]).astype(np.uint8)
        # im = Image.fromarray(img)
        # im = np.asarray(im)
        im = cv2.cvtColor(img,cv2.COLOR_GRAY2RGB)
        im = im[50: 430, 130: 520]
        # im.save('./images/'+str(time.time())+'.jpeg')
        taskqueue.put([im, str(time.time())])
        return line,

    def run(self):
        lidar = RPLidar(self.PORT_NAME)
        fig = plt.figure()
        ax = plt.subplot(111, projection='polar')
        line = ax.scatter([0, 0], [0, 0], s=1, c=[self.IMIN, self.IMAX], cmap=plt.cm.Oranges_r, lw=0)
        ax.set_rmax(self.DMAX)
        ax.set_rticks([int(self.DMAX*3/4), self.DMAX])
        ax.grid(True)
        iterator = lidar.iter_scans(max_buf_meas=800)
        ani = animation.FuncAnimation(fig, self.update_line, fargs=(iterator, line, fig), interval=1)
        plt.show()
        lidar.stop()
        lidar.disconnect()


class ConsumerThread(threading.Thread):
    def __init__(self, name=None):
        super(ConsumerThread, self).__init__()
        self.name = name
        self.trackMovement = TrackMovement()

    def run(self):
        global taskqueue
        global roiTracked
        print("consumer")
        flag = True

        while flag:
            if not taskqueue.empty():
                # print(taskqueue.qsize())
                roiOriginal, taskTime = taskqueue.get()
                roi = self.trackMovement.detectAndTrack(roiOriginal, taskTime)
                roiTracked = roi
                # print("roiTracked type="+str(type(roiTracked)))
                # print(roiTracked.shape)
                # print(taskqueue.qsize())
            else:
                time.sleep(1)
                # roiTracked = noActivity
                # print("taskqueue is empty")
        print("end of consumer")
        taskqueue.task_done()


client = pymongo.MongoClient()
mydb = client["lidar"]
mycollection = mydb["trackingViolation"]


app = dash.Dash(
    __name__,
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

app.title = "Godzooki Clean Room Human Tracking"
server = app.server
app.config["suppress_callback_exceptions"] = True

APP_PATH = str(pathlib.Path(__file__).parent.resolve())
df = pd.read_csv(os.path.join(APP_PATH, os.path.join("data", "external", "spc_data.csv")))

params = list(df)
max_length = len(df)

suffix_row = "_row"
suffix_button_id = "_button"
suffix_sparkline_graph = "_sparkline_graph"
suffix_count = "_count"
suffix_ooc_n = "_OOC_number"
suffix_ooc_g = "_OOC_graph"
suffix_indicator = "_indicator"


def build_banner():
    return html.Div(
        id="banner",
        className="banner",
        children=[
            html.Div(
                id="banner-text",
                children=[
                    html.H5("Godzooki Clean Room Human Tracking"),
                    html.H6("To Prevent Contamination"),
                ],
            ),
            html.Div(
                id="banner-logo",
                children=[
                    html.Button(
                        id="learn-more-button", children="LEARN MORE", n_clicks=0
                    ),
                    html.Img(id="logo", src=app.get_asset_url("dash-logo-new.png")),
                ],
            ),
        ],
    )


def build_tabs():
    return html.Div(
        id="tabs",
        className="tabs",
        children=[
            dcc.Tabs(
                id="app-tabs",
                value="tab2",
                className="custom-tabs",
                children=[
                    dcc.Tab(
                        id="Specs-tab",
                        label="Historic Data",
                        value="tab1",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                    ),
                    dcc.Tab(
                        id="Control-chart-tab",
                        label="Live",
                        value="tab2",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                    ),
                ],
            )
        ],
    )


def init_df():
    ret = {}
    for col in list(df[1:]):
        data = df[col]
        stats = data.describe()

        ret.update(
            {
                col: {
                    "count": stats["count"].tolist(),
                    "data": data,
                }
            }
        )

    return ret


state_dict = init_df()


def init_value_setter_store():
    # Initialize store data
    state_dict = init_df()
    return state_dict


def build_tab_1():
    maxDate = mycollection.find_one(sort=[("date", -1)])["date"]
    minDate = mycollection.find_one(sort=[("date", 1)])["date"]
    # minDate = datetime.datetime(2021, 4, 11, 00, 00, 00)
    # maxDate = datetime.datetime(2021, 4, 13, 00, 00, 00)
    minDate -= datetime.timedelta(days=1)
    maxDate += datetime.timedelta(days=1)
    print(minDate, "build_tab_1", maxDate)
    return [
        # Manually select metrics
        html.Div(
            id="settings-menu",
            children=[
                html.H6("Select the Data range to view the historic Violations..."),
                html.Br(),
                html.Div(
                    id="metric-select-menu",
                    # className='five columns',
                    children=[
                        dcc.DatePickerRange(
                            id="metric-date-menu",
                            min_date_allowed=minDate,
                            calendar_orientation='vertical',
                            max_date_allowed=maxDate,
                        ),
                        html.Div(id='output-container-date-picker-range'),
                    ],
                ),
            ],
        ),
        html.Div(
            id="value-setter-menu",
            # className='six columns',
            children=[
                html.Div(id="value-setter-panel"),
                # html.Br(),
                # html.Div(
                #     id="button-div",
                #     children=[
                #         html.Button("Update", id="value-setter-set-btn"),
                #         html.Button(
                #             "View current setup",
                #             id="value-setter-view-btn",
                #             n_clicks=0,
                #         ),
                #     ],
                # ),
                # html.Div(
                #     id="value-setter-view-output", className="output-datatable"
                # ),
            ],
        ),
    ]

# ===== Callbacks to update values based on store data and dropdown selection =====
@app.callback(
    output=[
        Output("value-setter-panel", "children"),
    ],
    inputs=[Input("metric-date-menu", "start_date"), Input("metric-date-menu", "end_date")],
)
def build_value_setter_panel(start_date, end_date):
    print("debugging...")
    if(start_date is not None) and (end_date is not None):
        print(start_date, end_date)
        figure, numberOfViolation = generate_figure(start_date, end_date)
        return (
            [
                # build_value_setter_line("value-setter-panel-header"),
                html.Div(
                    id="ooc-piechart-outer",
                    # className="four columns",
                    children=[
                        generate_section_banner("Historic Violation"),
                        figure,
                        generate_section_banner(str(numberOfViolation) + " violations observed"),
                    ],
                ),
            ],
        )
    else:
        return ([""],)

def build_value_setter_line(line_num):
    return html.Div(
        id=line_num,
        children=[
            html.H5("Godzooki Clean Room Human Tracking"),
        ],
    )


def generate_figure(start_date, end_date):
    """[summary]

    Args:
        start_date ([type]): [description]
        end_date ([type]): [description]

    Returns:
        [type]: [description]
    """
    print(start_date, "generate_figure", end_date)
    print(type(start_date), "generate_figure", type(end_date))
    roiTracked = cv2.imread('./data/images/clean_roi.jpg')
    roiTracked = roiTracked[50: 430, 130: 520]
    sensitive_startpoint = (135,125)
    sensitive_endpoint = (175,160)
    # over_startpoint = (145,85)
    over_startpoint = (145,45)
    # overn_endpoint = (190,120)
    overn_endpoint = (195,90)
    # sla_startpoint = (215,70)
    sla_startpoint = (215,95)
    sla_endpoint = (245,170)
    roiTracked = cv2.rectangle(roiTracked, sensitive_startpoint, sensitive_endpoint, (255, 0, 0), 1)
    roiTracked = cv2.rectangle(roiTracked, over_startpoint, overn_endpoint, (0, 0, 255), 1)
    roiTracked = cv2.rectangle(roiTracked, sla_startpoint, sla_endpoint, (0, 0, 255), 1)
    mpt_fig, ax = plt.subplots()
    ax.imshow(roiTracked)
    # start = datetime.datetime(2021, 4, 11, 00, 00, 00)
    # end = datetime.datetime(2021, 4, 13, 00, 00, 00)
    start = datetime.datetime.strptime(start_date, '%Y-%m-%d')
    end = datetime.datetime.strptime(end_date, '%Y-%m-%d')
    end += datetime.timedelta(days=1)
    print(start, "generate_figure", end)
    records = mycollection.find({'date': {'$gte': start, '$lt': end}, 'violated': {'$ne': 'Not'}})
    print("after records")
    recordNumber = 0
    for doc in records:
        # print(doc)
        recordNumber += 1
        coordinates = pd.DataFrame.from_dict(doc['coordinates']).to_numpy()
        x = coordinates[:, 0]
        y = coordinates[:, 1]
        startX = x[0]
        startY = y[0]
        endX = x[len(x)-1]
        endY = y[len(y)-1]
        ax.plot(x, y, 'r-', linewidth=1)
        ax.scatter(np.array(startX), np.array(startY), color='b', s=50)
        ax.scatter(np.array(endX), np.array(endY), color='#1fb4aa', s=50)

    print(recordNumber)
    canvas = FigureCanvasAgg(mpt_fig)
    print("after canvas")
    # Retrieve a view on the renderer buffer
    canvas.draw()
    buf = canvas.buffer_rgba()
    # convert to a NumPy array
    X = np.asarray(buf)
    fig = px.imshow(X)
    return dcc.Graph(id="graph", figure=fig, style={'width': '100vh', 'height': '100vh'}), recordNumber


def generate_modal():
    return html.Div(
        id="markdown",
        className="modal",
        children=(
            html.Div(
                id="markdown-container",
                className="markdown-container",
                children=[
                    html.Div(
                        className="close-container",
                        children=html.Button(
                            "Close",
                            id="markdown_close",
                            n_clicks=0,
                            className="closeButton",
                        ),
                    ),
                    html.Div(
                        className="markdown-text",
                        children=dcc.Markdown(
                            children=(
                                """
                        ###### What is this app about?

                        This is a dashboard for monitoring real-time and historic human movement violation in Filter Insert area of Godzooki clean room.

                        ###### What does this app shows

                        Click on `HISTORIC DATA` tab and select date range to view violation of movement to "Filter Insert area".
                        Dark blue circle on the violation path is the starting point and light blue circle is the ending point.
                    """
                            )
                        ),
                    ),
                ],
            )
        ),
    )


def build_quick_stats_panel():
    return html.Div(
        id="quick-stats",
        className="row",
        children=[
            html.Div(
                id="card-1",
                children=[
                    html.P(""),
                ],
            ),
            html.Div(
                id="card-2",
                children=[
                    html.P(""),
                ],
            ),
        ],
    )


def generate_section_banner(title):
    return html.Div(className="section-banner", children=title)


def build_top_panel(stopped_interval):
    return html.Div(
        id="top-section-container",
        className="row",
        children=[
            # Metrics summary
            html.Div(
                id="metric-summary-session",
                className="eight columns",
                children=[
                    generate_section_banner("Live movement in Clean Room"),
                    dcc.Graph(id='graph', figure={}),
                    dcc.Interval(id="interval", interval=350),
                ],
            ),
        ],
    )

@app.callback(Output("graph", "figure"), Input("interval", "n_intervals"))
def image_trigger(n_intervals):
    # img = cv2.imread('./data/images/roi.jpg')
    # print("img type="+str(type(img)))
    # print("roiTracked type="+str(type(roiTracked)))
    # rgb = cv2.cvtColor(roiTracked, cv2.COLOR_RGBA2RGB)
    fig = px.imshow(roiTracked)
    # fig = px.imshow(img)
    return fig

def update_sparkline(interval, param):
    x_array = state_dict["Batch"]["data"].tolist()
    y_array = state_dict[param]["data"].tolist()

    if interval == 0:
        x_new = y_new = None

    else:
        if interval >= max_length:
            total_count = max_length
        else:
            total_count = interval
        x_new = x_array[:total_count][-1]
        y_new = y_array[:total_count][-1]

    return dict(x=[[x_new]], y=[[y_new]]), [0]


def update_count(interval, col, data):
    if interval == 0:
        return "0", "0.00%", 0.00001, "#92e0d3"

    if interval > 0:

        if interval >= max_length:
            total_count = max_length - 1
        else:
            total_count = interval - 1

        ooc_percentage_f = data[col]["ooc"][total_count] * 100
        ooc_percentage_str = "%.2f" % ooc_percentage_f + "%"

        # Set maximum ooc to 15 for better grad bar display
        if ooc_percentage_f > 15:
            ooc_percentage_f = 15

        if ooc_percentage_f == 0.0:
            ooc_grad_val = 0.00001
        else:
            ooc_grad_val = float(ooc_percentage_f)

        # Set indicator theme according to threshold 5%
        if 0 <= ooc_grad_val <= 5:
            color = "#92e0d3"
        elif 5 < ooc_grad_val < 7:
            color = "#f4d44d"
        else:
            color = "#FF0000"

    return str(total_count + 1), ooc_percentage_str, ooc_grad_val, color


app.layout = html.Div(
    id="big-app-container",
    children=[
        build_banner(),
        dcc.Interval(
            id="interval-component",
            interval=2 * 1000,  # in milliseconds
            n_intervals=50,  # start at batch 50
            disabled=True,
        ),
        html.Div(
            id="app-container",
            children=[
                build_tabs(),
                # Main app
                html.Div(id="app-content"),
            ],
        ),
        dcc.Store(id="value-setter-store", data=init_value_setter_store()),
        dcc.Store(id="n-interval-stage", data=50),
        generate_modal(),
    ],
)


@app.callback(
    [Output("app-content", "children"), Output("interval-component", "n_intervals")],
    [Input("app-tabs", "value")],
    [State("n-interval-stage", "data")],
)
def render_tab_content(tab_switch, stopped_interval):
    if tab_switch == "tab1":
        return build_tab_1(), stopped_interval
    return (
        html.Div(
            id="status-container",
            children=[
                build_quick_stats_panel(),
                html.Div(
                    id="graphs-container",
                    children=[build_top_panel(stopped_interval)],
                ),
            ],
        ),
        stopped_interval,
    )


# Update interval
@app.callback(
    Output("n-interval-stage", "data"),
    [Input("app-tabs", "value")],
    [
        State("interval-component", "n_intervals"),
        State("interval-component", "disabled"),
        State("n-interval-stage", "data"),
    ],
)
def update_interval_state(tab_switch, cur_interval, disabled, cur_stage):
    if disabled:
        return cur_interval

    if tab_switch == "tab1":
        return cur_interval
    return cur_stage


# Callbacks for stopping interval update
@app.callback(
    [Output("interval-component", "disabled"), Output("stop-button", "buttonText")],
    [Input("stop-button", "n_clicks")],
    [State("interval-component", "disabled")],
)
def stop_production(n_clicks, current):
    if n_clicks == 0:
        return True, "start"
    return not current, "stop" if current else "start"


# ======= Callbacks for modal popup =======
@app.callback(
    Output("markdown", "style"),
    [Input("learn-more-button", "n_clicks"), Input("markdown_close", "n_clicks")],
)
def update_click_output(button_click, close_click):
    ctx = dash.callback_context

    if ctx.triggered:
        prop_id = ctx.triggered[0]["prop_id"].split(".")[0]
        if prop_id == "learn-more-button":
            return {"display": "block"}

    return {"display": "none"}


# ======= update progress gauge =========
@app.callback(
    output=Output("progress-gauge", "value"),
    inputs=[Input("interval-component", "n_intervals")],
)
def update_gauge(interval):
    if interval < max_length:
        total_count = interval
    else:
        total_count = max_length

    return int(total_count)


# decorator for list of output
def create_callback(param):
    def callback(interval, stored_data):
        count, ooc_n, ooc_g_value, indicator = update_count(
            interval, param, stored_data
        )
        spark_line_data = update_sparkline(interval, param)
        return count, spark_line_data, ooc_n, ooc_g_value, indicator

    return callback


for param in params[1:]:
    update_param_row_function = create_callback(param)
    app.callback(
        output=[
            Output(param + suffix_count, "children"),
            Output(param + suffix_sparkline_graph, "extendData"),
            Output(param + suffix_ooc_n, "children"),
            Output(param + suffix_ooc_g, "value"),
            Output(param + suffix_indicator, "color"),
        ],
        inputs=[Input("interval-component", "n_intervals")],
        state=[State("value-setter-store", "data")],
    )(update_param_row_function)


#  ======= button to choose/update figure based on click ============
@app.callback(
    output=Output("control-chart-live", "figure"),
    inputs=[
        Input("interval-component", "n_intervals"),
        Input(params[1] + suffix_button_id, "n_clicks"),
        Input(params[2] + suffix_button_id, "n_clicks"),
        Input(params[3] + suffix_button_id, "n_clicks"),
        Input(params[4] + suffix_button_id, "n_clicks"),
        Input(params[5] + suffix_button_id, "n_clicks"),
        Input(params[6] + suffix_button_id, "n_clicks"),
        Input(params[7] + suffix_button_id, "n_clicks"),
    ],
    state=[State("value-setter-store", "data"), State("control-chart-live", "figure")],
)

# Update piechart
@app.callback(
    output=Output("piechart", "figure"),
    inputs=[Input("interval-component", "n_intervals")],
    state=[State("value-setter-store", "data")],
)
def update_piechart(interval, stored_data):
    if interval == 0:
        return {
            "data": [],
            "layout": {
                "font": {"color": "white"},
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
            },
        }

    if interval >= max_length:
        total_count = max_length - 1
    else:
        total_count = interval - 1

    values = []
    colors = []
    for param in params[1:]:
        ooc_param = (stored_data[param]["ooc"][total_count] * 100) + 1
        values.append(ooc_param)
        if ooc_param > 6:
            colors.append("#f45060")
        else:
            colors.append("#91dfd2")

    new_figure = {
        "data": [
            {
                "labels": params[1:],
                "values": values,
                "type": "pie",
                "marker": {"colors": colors, "line": dict(color="white", width=2)},
                "hoverinfo": "label",
                "textinfo": "label",
            }
        ],
        "layout": {
            "margin": dict(t=20, b=50),
            "uirevision": True,
            "font": {"color": "white"},
            "showlegend": False,
            "paper_bgcolor": "rgba(0,0,0,0)",
            "plot_bgcolor": "rgba(0,0,0,0)",
            "autosize": True,
        },
    }
    return new_figure


# Running the server
if __name__ == "__main__":
    p = ProducerThread(name='producer')
    p.start()
    c = ConsumerThread(name='consumer')
    c.start()
    app.run_server(debug=False, port=8050, host='0.0.0.0')
    # app.run_server(debug=True, port=8010, host='localhost')
    # print("task queue waiting")
    # taskqueue.join()